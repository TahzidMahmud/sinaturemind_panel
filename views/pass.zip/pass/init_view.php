<div class="container">
    <div class="row">
        <div class="row"></div>
    <div class="col-md-4" ></div>
    <div>
        
         <div class="card m-4"  style="margin-top:10vh;">
      <div class="card-header">
        <b>Change Password</b>
      </div>
      <div class="card-body m-4">
       
          
        <h4 class="card-title">Put Your Store Registered Phone Number Below</h4>
        <div class="row">
            <input class="form-control col-sm-8" id="phntxt" placeholde="Put Phone Number Here">
            <button class="btn btn-primary" id="getbtn">Get Password</button>
        </div><br>
        <p id="res" class="text text-danger"></p>
         <p id="res2" class="text text-success"></p>
        
      </div>
    </div>
        
    </div>
        
        
        
        
        
    </div>
</div>